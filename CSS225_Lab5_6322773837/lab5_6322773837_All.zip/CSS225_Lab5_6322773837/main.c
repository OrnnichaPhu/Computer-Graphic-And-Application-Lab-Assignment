//
//  main.c
//  CSS225_Lab5_6322773837
//
//  Created by Ornnicha Phueaksri on 18/2/2565 BE.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
