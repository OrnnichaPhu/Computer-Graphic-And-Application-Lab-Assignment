//
//  main.cpp
//  Problem1
//
//  Created by Ornnicha Phueaksri on 18/2/2565 BE.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int a;
    double b1;
    float b2;
    char c123;
    bool B;
    a = 7;
    b1=77.88;
    c123='B';
    printf("The variable a = %d\n", a);
    printf("The variable b1 = %lf\n", b1);
    printf("The variable b2 = %f\n", b2);
    printf("The variable c123 = %c\n", c123);
    printf("The variable B = %d\n", B);
    printf("press 0 to quit\n");
    int c;
    scanf("%d",&c);
    return 0;
}
